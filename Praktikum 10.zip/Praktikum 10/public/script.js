$(document).ready(function () {
    $(".play").click(function () {
        var playerChoose = $(".play").index(this);
        play(playerChoose);
    });

    function play(player) {
        var bot = Math.floor(Math.random() * 3);

        move(player, bot);

        var text = $(".text-condition");
        if (player == bot) {
            text.html("Draw");
        }
        else if ((player + 1) % 3 == bot) {
            text.html("Computer Win");
            win("bot-score");
        }
        else {
            text.html("Player Win");
            win("player-score");
        }
    }

    function move(player, bot) {
        const choose = ["rock", "paper", "scissors"];
        const result = $(".result");

        var playerImg = new Image();
        var botImg = new Image();
        var vs = document.createElement("h2");

        playerImg.src = `./images/${choose[player]}.png`;
        playerImg.style.height = "125px";
        playerImg.style.width = "125px";

        botImg.src = `./images/${choose[bot]}.png`;
        botImg.style.height = "125px";
        botImg.style.width = "125px";

        vs.innerHTML = "VS";

        result.empty();
        result.append(playerImg);
        result.append(vs);
        result.append(botImg);
    }

    function win(winner) {
        const max = 5;

        score = $("." + winner);
        score.html(parseInt(score.html()) + 1);

        if (score.html() == max) {
            if (winner == "player-score") {
                $(".winner").html("PLAYER");
            }
            else {
                $(".winner").html("COMPUTER");
            }

            $(".winner-container").css("display", "block");
        }
    }

    $(".restart").click(function () {
        $(".winner-container").css("display", "none");
        $(".player-score").html(0);
        $(".bot-score").html(0);
        $(".result").empty();
        $(".text-condition").empty();
    });
});