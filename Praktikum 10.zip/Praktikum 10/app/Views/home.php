<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rock Paper Scissors</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="main">
        <h1>
            Rock Paper Scissors
        </h1>

        <div class="score-board">
            <div class="player">
                <h3>Player</h3>
                <div class="player-score score">0</div>
            </div>
            <div class="bot">
                <h3>Computer</h3>
                <div class="bot-score score">0</div>
            </div>
        </div>

        <div class="choose">
            <button class="play rock"></button>
            <button class="play paper"></button>
            <button class="play scissors"></button>
        </div>

        <div>
            <h2>Last Move</h2>
            <div class="result"></div>
        </div>

        <h2 class="text-condition"></h2>

        <div class="winner-container">
            <div class="winner-content">
                <h2>The Winner is:</h2>
                <h2 class="winner">PLAYER</h2>

                <button class="btn restart">Play Again!</button>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="script.js"></script>
</body>

</html>