<?php
$conn = mysqli_connect("localhost", "root", "", "sql1");
$query = "SELECT * FROM karyawan";
$data = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Admin</title>
</head>

<body>
    <h1>Daftar Karyawan</h1>
    <a class="tambah" href="tambah.php">Tambah data</a>
    <br><br>
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <td>No.</td>
            <td>Nama</td>
            <td>Email</td>
            <td>Address</td>
            <td>Gender</td>
            <td>Position</td>
            <td>Status</td>
            <td>Action</td>
        </tr>
        <!-- print data from result -->
        <?php $i = 1; ?>
        <?php while ($row = mysqli_fetch_assoc($data)) : ?>
            <tr>
                <td><?= $i; ?></td>
                <td><?= $row["nama"]; ?></td>
                <td><?= $row["email"]; ?></td>
                <td><?= $row["address"]; ?></td>
                <td><?= $row["gender"]; ?></td>
                <td><?= $row["position"]; ?></td>
                <td><?= $row["status"]; ?></td>
                <td>
                    <a href="hapus.php?id=<?= $row["id"]; ?>"" class = " button">Delete</a>
                    <a href="update.php?id=<?= $row["id"]; ?>"" class = " button1">Update</a>
                </td>
                <?php $i++; ?>
            </tr>
        <?php endwhile; ?>
</body>
<style>
    .button {
        background-color: #04AA6D;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        float: right;
        margin-top: 30px;
        margin-right: 29%;
        font-size: 15px;
    }

    .button:hover {
        background-color: #45a049;
    }

    .tambah {
        background-color: skyblue;
        color: black;
        cursor: pointer;
        float: right;
        margin-top: 30px;
        margin-right: 29px;
        border: none;
        border-radius: 4px;
        font-size: 20px;
        padding: 15px 25px;
    }

    h1 {
        width: 70%;
        font-weight: 500px;
        background: #222;
        color: blue;
        outline: none;
        cursor: pointer;
        text-align: center;
        font-size: 40px;
        border: none;
        border-radius: 5px;
        padding: 10px 10px;
    }
</style>

</html>