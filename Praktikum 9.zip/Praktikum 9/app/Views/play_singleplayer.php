<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tic Tac Toe</title>
</head>

<style>
    * {
        font-family: Verdana, Geneva, Tahoma, sans-serif;
    }

    h1 {
        color: orangered;
        font-size: 45px;
    }

    .btn {
        width: 105px;
        height: 40px;
        border: 1px solid dodgerblue;
        margin: 10px;
        border-radius: 4px;
        background-color: dodgerblue;
        color: white;
        font-size: 20px;
        cursor: pointer;
    }

    .btn:disabled {
        width: 105px;
        height: 40px;
        border: 1px solid gray;
        margin: 10px;
        border-radius: 4px;
        background-color: gray;
        color: white;
        font-size: 20px;
        cursor: default;
    }

    .box {
        width: 80px;
        height: 52px;
        margin: auto;
        border: 1px solid gray;
        border-radius: 6px;
        font-size: 30px;
        text-align: center;
    }

    #print {
        color: dodgerblue;
        font-size: 20px;
    }

    .main {
        text-align: center;
    }
</style>

<body>
    <div class="main">
        <h1>TIC TAC TOE</h1>
        <p class="title">
            <button class="btn changePlayer" disabled onclick="changePlayer(0)">X</button>
            <button class="btn changePlayer" onclick="changePlayer(1)">0</button>
            <br><br>
        </p>

        <br><br>
        <input type="text" class="box" onclick="move(0, 'P');" readonly>
        <input type="text" class="box" onclick="move(1, 'P');" readonly>
        <input type="text" class="box" onclick="move(2, 'P');" readonly>
        <br><br>
        <input type="text" class="box" onclick="move(3, 'P');" readonly>
        <input type="text" class="box" onclick="move(4, 'P');" readonly>
        <input type="text" class="box" onclick="move(5, 'P');" readonly>
        <br><br>
        <input type="text" class="box" onclick="move(6, 'P');" readonly>
        <input type="text" class="box" onclick="move(7, 'P');" readonly>
        <input type="text" class="box" onclick="move(8, 'P');" readonly>

        <br><br><br>

        <div>
            <form action="/" method="get">
                <button type="submit" class="btn">
                    HOME
                </button>
            </form>

            <button class="btn" onclick="resetGame()">
                RESTART
            </button>
        </div>

        <br><br>
        <p id="print"></p>
    </div>
</body>

</html>

<script>
    var board = [0, 1, 2, 3, 4, 5, 6, 7, 8];
    var human = "P";
    var currPlayer = "X";
    var botPlayer = "0";
    var bot = "B";
    var iter = 0;
    var round = 0;
    var box = document.getElementsByClassName('box');

    function changePlayer(idx) {
        document.getElementsByClassName('changePlayer')[idx].disabled = true;
        document.getElementsByClassName('changePlayer')[1 - idx].disabled = false;
        document.getElementById('print').innerHTML = "";

        Array.from(box).forEach(e => {
            e.value = "";
            e.disabled = false;
        });
        round = 0;
        board = [0, 1, 2, 3, 4, 5, 6, 7, 8];

        if (idx == 0) {
            currPlayer = "X";
            botPlayer = "0";
        } else {
            currPlayer = "0";
            botPlayer = "X";

            round++;
            var index;
            if (<?php echo $difficulty ?> == 1) {
                index = Math.round(Math.random() * 8);
            } else {
                index = minimax(board, bot).index;
            }

            box[index].value = botPlayer;
            box[index].disabled = true;
            board[index] = bot;
        }
    }

    function disabledAll() {
        var box = document.getElementsByClassName('box');
        Array.from(box).forEach(e => {
            e.disabled = true;
        })
    }

    function move(idx, player) {
        if (board[idx] != "P" && board[idx] != "B") {
            round++;
            box[idx].value = currPlayer;
            box[idx].disabled = true;
            board[idx] = player;

            if (winning(board, player)) {
                document.getElementById('print').innerHTML = "You Win";
                return;
            } else if (round > 8) {
                document.getElementById('print').innerHTML = "Tie";
                return;
            } else {
                round++;
                var index;
                if (<?php echo $difficulty ?> == 1) {
                    index = Math.round(Math.random() * 8);
                    while (board[index] == 'P' || board[index] == 'B') {
                        index = Math.round(Math.random() * 8);
                    }
                } else {
                    index = minimax(board, bot).index;
                }

                box[index].value = botPlayer;
                box[index].disabled = true;
                board[index] = bot;

                if (winning(board, bot)) {
                    document.getElementById('print').innerHTML = "You Lose";
                    return;
                } else if (round > 8) {
                    document.getElementById('print').innerHTML = "Tie";
                    return;
                }
            }
        }
    }

    function resetGame() {
        document.getElementById('print').innerHTML = "";
        Array.from(box).forEach(e => {
            e.value = "";
            e.disabled = false;
        });
        round = 0;
        board = [0, 1, 2, 3, 4, 5, 6, 7, 8];
    }

    function minimax(reboard, player) {
        iter++;
        let array = availability(reboard);
        if (winning(reboard, human)) {
            return {
                score: -10
            };
        } else if (winning(reboard, bot)) {
            return {
                score: 10
            };
        } else if (array.length === 0) {
            return {
                score: 0
            };
        }

        var moves = [];
        for (var i = 0; i < array.length; i++) {
            var move = {};
            move.index = reboard[array[i]];
            reboard[array[i]] = player;

            if (player == bot) {
                var g = minimax(reboard, human);
                move.score = g.score;
            } else {
                var g = minimax(reboard, bot);
                move.score = g.score;
            }
            reboard[array[i]] = move.index;
            moves.push(move);
        }

        var bestMove;
        if (player === bot) {
            var bestScore = -10000;
            for (var i = 0; i < moves.length; i++) {
                if (moves[i].score > bestScore) {
                    bestScore = moves[i].score;
                    bestMove = i;
                }
            }
        } else {
            var bestScore = 10000;
            for (var i = 0; i < moves.length; i++) {
                if (moves[i].score < bestScore) {
                    bestScore = moves[i].score;
                    bestMove = i;
                }
            }
        }
        return moves[bestMove];
    }

    function availability(reboard) {
        return reboard.filter(s => s != "P" && s != "B");
    }

    function winning(board, player) {
        if (
            (board[0] == player && board[1] == player && board[2] == player) ||
            (board[3] == player && board[4] == player && board[5] == player) ||
            (board[6] == player && board[7] == player && board[8] == player) ||
            (board[0] == player && board[3] == player && board[6] == player) ||
            (board[1] == player && board[4] == player && board[7] == player) ||
            (board[2] == player && board[5] == player && board[8] == player) ||
            (board[0] == player && board[4] == player && board[8] == player) ||
            (board[2] == player && board[4] == player && board[6] == player)
        ) {
            return true;
        } else {
            return false;
        }
    }
</script>