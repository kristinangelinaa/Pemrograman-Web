<?php

namespace App\Controllers;

class HomeController extends BaseController
{

    public function index()
    {
        return view('home');
    }

    public function play()
    {
        if(isset($_REQUEST)){
            $request['mode'] = $_REQUEST['mode'];
            
            if(isset($_REQUEST['difficulty']) && $_REQUEST['mode'] == 'singleplayer' ){
                if($_REQUEST['difficulty'] < 1 || $_REQUEST['difficulty'] > 2){
                    return view('home');
                }
                
                $request['difficulty'] = $_REQUEST['difficulty'];
                return view('play_singleplayer', $request);
            }

            return view('play_multiplayer', $request);
        }

        return view('home');
    }
}
