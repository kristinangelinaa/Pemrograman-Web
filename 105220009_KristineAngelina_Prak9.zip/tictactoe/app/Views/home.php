<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tic Tac Toe</title>
</head>

<style>
    * {
        font-family: Verdana, Geneva, Tahoma, sans-serif;
    }

    h1 {
        color: orangered;
        font-size: 45px;
    }

    .main {
        text-align: center;
    }

    .btn {
        box-sizing: border-box;
        width: 95px;
        height: 40px;
        border: 1px solid dodgerblue;
        border-radius: 4px;
        background-color: dodgerblue;
        color: white;
        font-size: 20px;
        cursor: pointer;
        margin-top: 10px;
    }
</style>

<body>
    <div class="main">
        <form action="/play" method="get">
            <div>
                <h1>TIC TAC TOE</h1>

                <h3>Select Mode:</h3>
                <div>
                    <input type="radio" name="mode" id="singleplayer" value="singleplayer" style="cursor: pointer;" checked>
                    <label for="singleplayer" style="cursor: pointer;">Single Player</label>

                    <input type="radio" name="mode" id="multiplayer" value="multiplayer" style="cursor: pointer;">
                    <label for="multiplayer" style="cursor: pointer;">Multi Player</label>
                </div>
            </div>

            <div id="showDifficulty" style="margin-top: 20px;">
                Choose Difficulty of Bot:

                <select name="difficulty" id="difficulty">
                    <option value="1">baby bot</option>
                    <option value="2">minimax AI</option>
                </select>
            </div>

            <button type="submit" class="btn">Start!</button>
        </form>
    </div>
</body>

</html>

<script>
    var showDifficulty = document.getElementById('showDifficulty');
    var mode = document.getElementsByName('mode');
    var selection = document.getElementById('difficulty');

    mode[0].addEventListener("click", function() {
        changeMode(true)
    });
    mode[1].addEventListener("click", function() {
        changeMode(false)
    });

    function changeMode(isSingle) {
        if (isSingle) {
            showDifficulty.style.display = "block";
            selection.disabled = false;
        } else {
            showDifficulty.style.display = "none";
            selection.disabled = true;
        }
    }
</script>