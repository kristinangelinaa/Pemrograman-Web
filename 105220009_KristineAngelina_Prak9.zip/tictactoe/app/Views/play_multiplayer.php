<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tic Tac Toe</title>
</head>

<style>
    * {
        font-family: Verdana, Geneva, Tahoma, sans-serif;
    }

    h1 {
        color: orangered;
        font-size: 45px;
    }

    .btn {
        width: 105px;
        height: 40px;
        border: 1px solid dodgerblue;
        margin: 10px;
        border-radius: 4px;
        background-color: dodgerblue;
        color: white;
        font-size: 20px;
        cursor: pointer;
        text-decoration: none;
    }

    .box {
        width: 80px;
        height: 52px;
        margin: auto;
        border: 1px solid gray;
        border-radius: 6px;
        font-size: 30px;
        text-align: center;
    }

    #print {
        color: dodgerblue;
        font-size: 20px;
    }

    .main {
        text-align: center;
    }
</style>

<body>
    <div class="main">
        <h1>TIC TAC TOE</h1>
        <p class="title">
            Game starts by just Tap on box
            <br><br>
            First Player starts as <b>Player X</b>
            <br>And<br>
            Second Player as <b>Player 0</b>
        </p>

        <br><br>
        <input type="text" class="box" onclick="grid(0);" readonly>
        <input type="text" class="box" onclick="grid(1);" readonly>
        <input type="text" class="box" onclick="grid(2);" readonly>
        <br><br>
        <input type="text" class="box" onclick="grid(3);" readonly>
        <input type="text" class="box" onclick="grid(4);" readonly>
        <input type="text" class="box" onclick="grid(5);" readonly>
        <br><br>
        <input type="text" class="box" onclick="grid(6);" readonly>
        <input type="text" class="box" onclick="grid(7);" readonly>
        <input type="text" class="box" onclick="grid(8);" readonly>

        <br><br><br>

        <div>
            <form action="/" method="get">
                <button type="submit" class="btn">
                    HOME
                </button>
            </form>

            <button class="btn" onclick="resetGame()">
                RESTART
            </button>
        </div>

        <br><br>
        <p id="print">Player X Turn</p>
    </div>
</body>

</html>

<script>
    function disabledAll() {
        var box = document.getElementsByClassName('box');
        Array.from(box).forEach(e => {
            e.disabled = true;
        })
    }

    flag = 1;

    function checkFinish() {
        var box = document.getElementsByClassName('box');
        let combination = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6],
        ];

        var winner = 0;
        combination.forEach(e => {
            if ((box[e[0]].value == 'X' && box[e[1]].value == 'X' && box[e[2]].value == 'X') ||
                (box[e[0]].value == '0' && box[e[1]].value == '0' && box[e[2]].value == '0')) {
                winner = 1;
                disabledAll();
            }
        });

        if (winner == 1) {
            if (flag == 0) {
                document.getElementById('print').innerHTML = "Player X Win";
            } else {
                document.getElementById('print').innerHTML = "Player 0 Win";
            }
        } else if ((box[0].value == 'X' || box[0].value == '0') && (box[1].value == 'X' ||
                box[1].value == '0') && (box[2].value == 'X' || box[2].value == '0') &&
            (box[3].value == 'X' || box[3].value == '0') && (box[4].value == 'X' ||
                box[4].value == '0') && (box[5].value == 'X' || box[5].value == '0') &&
            (box[6].value == 'X' || box[6].value == '0') && (box[7].value == 'X' ||
                box[7].value == '0') && (box[8].value == 'X' || box[8].value == '0')) {
            document.getElementById('print').innerHTML = "Match Tie";
        } else {
            if (flag == 1) {
                document.getElementById('print').innerHTML = "Player X Turn";
            } else {
                document.getElementById('print').innerHTML = "Player 0 Turn";
            }
        }
    }

    function resetGame() {
        document.getElementById('print').innerHTML = "Player X Turn";
        flag = 1;

        var box = document.getElementsByClassName('box');
        Array.from(box).forEach(e => {
            e.value = "";
            e.disabled = false;
        });
    }

    function grid(idx) {
        var box = document.getElementsByClassName("box")[idx];
        if (flag == 1) {
            box.value = "X";
            box.disabled = true;
            flag = 0;
        } else {
            box.value = "0";
            box.disabled = true;
            flag = 1;
        }

        checkFinish();
    }
</script>